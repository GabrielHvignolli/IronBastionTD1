package com.gabriel.ironbastion;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import java.util.*;

public class GameView extends SurfaceView implements SurfaceHolder.Callback, Runnable {
    Thread thread; volatile boolean running=false;
    final Paint p=new Paint(3), text=new Paint(3); final Random rng=new Random();
    float W,H,sx,sy; long last;
    int credits=500, lives=20, wave=1, maxWaves=10, kills=0; float spawnTimer=0, nextWaveTimer=8;
    boolean started=false, gameOver=false, victory=false;
    int selectedType=1, selectedTank=-1;
    final ArrayList<Enemy> enemies=new ArrayList<>(); final ArrayList<Tank> tanks=new ArrayList<>(); final ArrayList<Shot> shots=new ArrayList<>(); final ArrayList<Boom> booms=new ArrayList<>();
    final ArrayList<Pad> pads=new ArrayList<>();
    final ArrayList<PointF> path=new ArrayList<>();
    final String[] names={"SCOUT","MEDIUM","HEAVY","ARTILLERY"}; final int[] costs={90,140,220,300};

    public GameView(Context c){ super(c); getHolder().addCallback(this); setFocusable(true); }
    @Override public void surfaceCreated(SurfaceHolder h){ initWorld(); resume(); }
    @Override public void surfaceChanged(SurfaceHolder h,int f,int w,int hh){ initWorld(); }
    @Override public void surfaceDestroyed(SurfaceHolder h){ pause(); }
    void initWorld(){ W=getWidth(); H=getHeight(); if(W<=0||H<=0)return; sx=W/1600f; sy=H/900f;
        path.clear(); float[][] pts={{1600,190},{1450,190},{1340,260},{1230,340},{1090,355},{970,320},{850,350},{730,430},{610,455},{500,410},{390,440},{280,520},{165,565},{0,565}}; for(float[] q:pts)path.add(new PointF(q[0]*sx,q[1]*sy));
        if(pads.isEmpty()){ float[][] a={{1320,520},{1125,510},{960,575},{790,585},{620,620},{460,650},{1220,675},{930,735},{690,735},{350,735}}; for(float[] q:a)pads.add(new Pad(q[0],q[1])); }
    }
    void newGame(){ credits=500;lives=20;wave=1;kills=0;spawnTimer=0;nextWaveTimer=2;enemies.clear();tanks.clear();shots.clear();booms.clear(); for(Pad d:pads)d.occupied=false; started=true;gameOver=false;victory=false;selectedTank=-1; }
    @Override public void run(){ last=System.nanoTime(); while(running){ long n=System.nanoTime(); float dt=Math.min(.033f,(n-last)/1e9f); last=n; update(dt); drawGame(); try{Thread.sleep(12);}catch(Exception e){} } }
    void update(float dt){ if(!started||gameOver||victory)return;
        nextWaveTimer-=dt; if(nextWaveTimer<=0){ spawnTimer-=dt; int target=8+wave*2; int spawned=0; for(Enemy e:enemies)if(e.wave==wave)spawned++; if(spawned<target && spawnTimer<=0){ enemies.add(new Enemy(wave)); spawnTimer=Math.max(.35f,1.15f-wave*.06f); } else if(spawned>=target){ boolean alive=false; for(Enemy e:enemies)if(e.wave==wave&&!e.dead)alive=true; if(!alive){ if(wave>=maxWaves){ victory=true; } else { wave++; nextWaveTimer=6; credits+=120; } } } }
        for(Enemy e:enemies)e.update(dt); enemies.removeIf(e->e.remove);
        for(Tank t:tanks)t.update(dt); for(Shot s:shots)s.update(dt); shots.removeIf(s->s.dead); for(Boom b:booms)b.t+=dt; booms.removeIf(b->b.t>.5f);
    }
    class Enemy{ float x,y,hp,maxhp,speed; int idx=0,wave; boolean dead=false,remove=false; Enemy(int w){wave=w;x=path.get(0).x;y=path.get(0).y;maxhp=90+w*28;hp=maxhp;speed=(72+w*3)*sx;}
        void update(float dt){ if(dead){remove=true;return;} if(idx>=path.size()-1){lives--;dead=true;if(lives<=0)gameOver=true;return;} PointF t=path.get(idx+1); float dx=t.x-x,dy=t.y-y,d=(float)Math.hypot(dx,dy); if(d<7*sx){idx++;return;} x+=dx/d*speed*dt;y+=dy/d*speed*dt; }
        void hit(float d){hp-=d;if(hp<=0&&!dead){dead=true;credits+=18+wave*2;kills++;booms.add(new Boom(x,y));}}
    }
    class Tank{ float x,y,range,rate,damage,cool=0; int type,level=1,padIndex; Tank(int type,int pi){this.type=type;padIndex=pi;Pad d=pads.get(pi);x=d.x*sx;y=d.y*sy; if(type==0){range=230;rate=.48f;damage=17;}if(type==1){range=265;rate=.72f;damage=31;}if(type==2){range=285;rate=1.05f;damage=55;}if(type==3){range=390;rate=1.55f;damage=92;} range*=sx;}
        void update(float dt){cool-=dt;if(cool>0)return; Enemy best=null;float bd=1e9f;for(Enemy e:enemies){if(e.dead)continue;float d=dist(x,y,e.x,e.y);if(d<range&&d<bd){bd=d;best=e;}} if(best!=null){shots.add(new Shot(x,y,best,this));cool=rate/(1+.12f*(level-1));}}
        int upgradeCost(){return 80*level + type*25;} void upgrade(){int c=upgradeCost();if(credits>=c&&level<5){credits-=c;level++;damage*=1.22f;range*=1.06f;}}
    }
    class Shot{float x,y;Enemy target;Tank src;boolean dead=false;Shot(float x,float y,Enemy e,Tank t){this.x=x;this.y=y;target=e;src=t;}void update(float dt){if(target.dead){dead=true;return;}float dx=target.x-x,dy=target.y-y,d=(float)Math.hypot(dx,dy),v=(src.type==3?700:1100)*sx;if(d<v*dt+8){target.hit(src.damage);booms.add(new Boom(target.x,target.y));dead=true;}else{x+=dx/d*v*dt;y+=dy/d*v*dt;}}}
    class Boom{float x,y,t=0;Boom(float a,float b){x=a;y=b;}}
    class Pad{float x,y;boolean occupied=false;Pad(float a,float b){x=a;y=b;}}
    float dist(float a,float b,float c,float d){return(float)Math.hypot(c-a,d-b);} 

    @Override public boolean onTouchEvent(MotionEvent e){ if(e.getAction()!=MotionEvent.ACTION_UP)return true; float x=e.getX(),y=e.getY(); if(!started||gameOver||victory){ if(x>W*.36f&&x<W*.64f&&y>H*.58f&&y<H*.75f)newGame(); return true; }
        if(y>H*.86f){ float bw=W*.12f; for(int i=0;i<4;i++){float bx=W*.02f+i*bw;if(x>bx&&x<bx+bw*.92f){selectedType=i;selectedTank=-1;return true;}} if(x>W*.78f&&x<W*.91f){ airstrike();return true;} }
        if(selectedTank>=0 && x>W*.76f && y>H*.57f && y<H*.77f){tanks.get(selectedTank).upgrade();return true;}
        for(int i=0;i<tanks.size();i++){Tank t=tanks.get(i);if(dist(x,y,t.x,t.y)<45*sx){selectedTank=i;return true;}}
        for(int i=0;i<pads.size();i++){Pad d=pads.get(i);float px=d.x*sx,py=d.y*sy;if(!d.occupied&&dist(x,y,px,py)<48*sx){int c=costs[selectedType];if(credits>=c){credits-=c;d.occupied=true;tanks.add(new Tank(selectedType,i));selectedTank=tanks.size()-1;}return true;}}
        return true;
    }
    void airstrike(){ if(credits<180)return;credits-=180;for(Enemy e:enemies)if(!e.dead)e.hit(65+wave*5); for(int i=0;i<8;i++)booms.add(new Boom((450+rng.nextInt(900))*sx,(210+rng.nextInt(370))*sy)); }

    void drawGame(){ Canvas c=null;try{c=getHolder().lockCanvas();if(c==null)return;drawBg(c);drawWorld(c);drawHud(c);}finally{if(c!=null)getHolder().unlockCanvasAndPost(c);} }
    void drawBg(Canvas c){ c.drawColor(Color.rgb(24,31,28));
        p.setColor(Color.rgb(54,69,53)); c.drawRect(0,0,W,H,p);
        p.setColor(Color.rgb(83,86,62)); for(int i=0;i<80;i++){float x=(i*173%1600)*sx,y=(90+(i*97)%650)*sy;c.drawCircle(x,y,(5+(i%4)*3)*sx,p);} 
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(80*sx);p.setStrokeCap(Paint.Cap.ROUND);p.setColor(Color.rgb(73,72,67));Path road=new Path();road.moveTo(path.get(0).x,path.get(0).y);for(int i=1;i<path.size();i++)road.lineTo(path.get(i).x,path.get(i).y);c.drawPath(road,p);p.setStrokeWidth(4*sx);p.setColor(Color.rgb(150,134,96));c.drawPath(road,p);p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(47,58,49));c.drawRect(0,H*.78f,W,H,p);
    }
    void drawWorld(Canvas c){
        for(int i=0;i<pads.size();i++){Pad d=pads.get(i);float x=d.x*sx,y=d.y*sy;p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4*sx);p.setColor(d.occupied?Color.rgb(90,104,80):Color.rgb(185,156,96));c.drawCircle(x,y,42*sx,p);c.drawCircle(x,y,30*sx,p);p.setStyle(Paint.Style.FILL);}
        for(Enemy e:enemies)if(!e.dead)drawEnemy(c,e);
        for(int i=0;i<tanks.size();i++)drawTank(c,tanks.get(i),i==selectedTank);
        p.setColor(Color.rgb(255,190,74));for(Shot s:shots)c.drawCircle(s.x,s.y,5*sx,p);
        for(Boom b:booms){float r=(12+42*b.t)*sx;p.setColor(Color.argb((int)(220*(1-b.t/.5f)),255,145,40));c.drawCircle(b.x,b.y,r,p);p.setColor(Color.argb((int)(180*(1-b.t/.5f)),255,220,110));c.drawCircle(b.x,b.y,r*.45f,p);} }
    void drawEnemy(Canvas c,Enemy e){ p.setColor(Color.rgb(87,52,47));c.save();c.translate(e.x,e.y);c.rotate(-15);c.drawRoundRect(-26*sx,-14*sy,26*sx,14*sy,7*sx,7*sx,p);p.setColor(Color.rgb(131,75,61));c.drawCircle(4*sx,0,11*sx,p);p.setStrokeWidth(5*sx);p.setColor(Color.rgb(50,44,39));c.drawLine(7*sx,0,36*sx,0,p);c.restore();float bw=50*sx;p.setColor(Color.rgb(38,20,20));c.drawRect(e.x-bw/2,e.y-27*sy,e.x+bw/2,e.y-21*sy,p);p.setColor(Color.rgb(209,57,44));c.drawRect(e.x-bw/2,e.y-27*sy,e.x-bw/2+bw*(e.hp/e.maxhp),e.y-21*sy,p); }
    void drawTank(Canvas c,Tank t,boolean sel){ if(sel){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5*sx);p.setColor(Color.rgb(70,182,255));c.drawCircle(t.x,t.y,45*sx,p);p.setStyle(Paint.Style.FILL);} int[] col={Color.rgb(108,128,74),Color.rgb(92,109,66),Color.rgb(77,91,62),Color.rgb(123,106,72)};p.setColor(col[t.type]);c.drawRoundRect(t.x-28*sx,t.y-17*sy,t.x+28*sx,t.y+17*sy,8*sx,8*sx,p);p.setColor(Color.rgb(54,64,47));c.drawCircle(t.x+3*sx,t.y,13*sx,p);p.setStrokeWidth((t.type==3?7:6)*sx);c.drawLine(t.x+7*sx,t.y,t.x+(t.type==3?44:37)*sx,t.y,p);p.setColor(Color.rgb(20,25,21));text.setTextSize(15*sx);text.setColor(Color.WHITE);text.setFakeBoldText(true);c.drawText("L"+t.level,t.x-10*sx,t.y-24*sy,text); }
    void panel(Canvas c,float l,float t,float r,float b){p.setColor(Color.argb(235,19,24,27));c.drawRoundRect(l,t,r,b,14*sx,14*sx,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2*sx);p.setColor(Color.rgb(74,84,88));c.drawRoundRect(l,t,r,b,14*sx,14*sx,p);p.setStyle(Paint.Style.FILL);} 
    void drawHud(Canvas c){ text.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));
        panel(c,W*.015f,H*.018f,W*.39f,H*.105f); drawTxt(c,"$ "+credits,W*.035f,H*.074f,30,Color.WHITE);drawTxt(c,"WAVE "+wave+"/"+maxWaves,W*.18f,H*.074f,27,Color.WHITE);drawTxt(c,"❤ "+lives,W*.32f,H*.074f,28,Color.rgb(245,91,72));
        panel(c,W*.74f,H*.018f,W*.985f,H*.105f);drawTxt(c,nextWaveTimer>0?"NEXT WAVE  "+(int)Math.ceil(nextWaveTimer)+"s":"ENEMIES INBOUND",W*.765f,H*.074f,23,Color.rgb(232,185,88));
        float bw=W*.12f;for(int i=0;i<4;i++){float l=W*.02f+i*bw,t=H*.865f,r=l+bw*.92f,b=H*.985f;panel(c,l,t,r,b);if(i==selectedType){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4*sx);p.setColor(Color.rgb(65,173,255));c.drawRoundRect(l,t,r,b,14*sx,14*sx,p);p.setStyle(Paint.Style.FILL);}drawTxt(c,names[i],l+12*sx,t+28*sy,15,Color.WHITE);drawTxt(c,"$"+costs[i],l+12*sx,b-13*sy,17,Color.rgb(235,191,89));drawMiniTank(c,(l+r)/2,t+64*sy,i);} 
        panel(c,W*.51f,H*.865f,W*.635f,H*.985f);drawTxt(c,"AIRSTRIKE",W*.528f,H*.905f,17,Color.WHITE);drawTxt(c,"$180",W*.555f,H*.956f,21,Color.rgb(235,191,89));
        if(selectedTank>=0){Tank t=tanks.get(selectedTank);panel(c,W*.75f,H*.55f,W*.985f,H*.83f);drawTxt(c,names[t.type]+"  LV."+t.level,W*.77f,H*.6f,23,Color.WHITE);drawTxt(c,"DMG  "+(int)t.damage,W*.77f,H*.645f,18,Color.LTGRAY);drawTxt(c,"RANGE  "+(int)(t.range/sx),W*.77f,H*.685f,18,Color.LTGRAY);p.setColor(Color.rgb(68,136,73));c.drawRoundRect(W*.77f,H*.72f,W*.965f,H*.79f,10*sx,10*sx,p);drawTxt(c,t.level<5?"UPGRADE  $"+t.upgradeCost():"MAX LEVEL",W*.79f,H*.766f,18,Color.WHITE);}
        if(!started||gameOver||victory){p.setColor(Color.argb(215,5,8,10));c.drawRect(0,0,W,H,p);drawTxt(c,"IRON BASTION",W*.345f,H*.34f,52,Color.WHITE);drawTxt(c,gameOver?"BASE DESTROYED":victory?"VICTORY":"MOBILE TANK DEFENSE",W*.39f,H*.42f,25,gameOver?Color.rgb(240,80,65):Color.rgb(225,180,80));p.setColor(Color.rgb(180,119,38));c.drawRoundRect(W*.36f,H*.58f,W*.64f,H*.75f,18*sx,18*sx,p);drawTxt(c,gameOver||victory?"PLAY AGAIN":"START BATTLE",W*.42f,H*.68f,27,Color.WHITE);if(gameOver||victory)drawTxt(c,"Kills: "+kills,W*.45f,H*.51f,22,Color.LTGRAY);}
    }
    void drawMiniTank(Canvas c,float x,float y,int type){int[] col={Color.rgb(108,128,74),Color.rgb(92,109,66),Color.rgb(77,91,62),Color.rgb(123,106,72)};p.setColor(col[type]);c.drawRoundRect(x-25*sx,y-11*sy,x+25*sx,y+11*sy,6*sx,6*sx,p);p.setColor(Color.rgb(55,64,48));c.drawCircle(x+3*sx,y,9*sx,p);p.setStrokeWidth(4*sx);c.drawLine(x+6*sx,y,x+33*sx,y,p);} 
    void drawTxt(Canvas c,String s,float x,float y,float size,int color){text.setTextSize(size*sx);text.setColor(color);text.setStyle(Paint.Style.FILL);c.drawText(s,x,y,text);} 
    public void resume(){if(running)return;running=true;thread=new Thread(this,"game");thread.start();}
    public void pause(){running=false;if(thread!=null){try{thread.join(500);}catch(Exception ignored){}}}
}
