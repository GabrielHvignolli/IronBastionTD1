# Iron Bastion TD — Android prototype
Native Android tank tower-defense prototype designed for landscape mobile play.

## Included
- 10 waves
- 4 defense classes: Scout, Medium, Heavy, Artillery
- touch placement on build pads
- enemy route/pathing
- automatic targeting and projectiles
- credits, lives, kills and wave progression
- tank upgrades to level 5
- airstrike ability
- win/lose/restart flow
- fullscreen landscape UI drawn natively with Android Canvas

## Build
Open this folder in Android Studio (JDK 17), let Gradle sync, then Build > Build APK(s).
The debug APK will be under app/build/outputs/apk/debug/app-debug.apk.
